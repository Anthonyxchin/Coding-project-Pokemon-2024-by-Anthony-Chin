import random


# Green talks about the PURPOSE of the code

""" Orange talks about the FUNCTION of the code """





#Allows for random number generation
# Define a class for Pokemon moves which makes it easier to reuse these assets when my pokemon uses a move
# This allows some sort of personalization within each move to make it easier to understand the rng behind each of them
class Move:
    def __init__(self, name, min_damage, max_damage):
        """
        Initializes the MOVE object.
        Args:
            name (str): The name of the move.
            min_damage (int): The minimum damage the move can inflict.
            max_damage (int): The maximum damage the move can inflict.
        """
        self.name = name
        self.min_damage = min_damage
        self.max_damage = max_damage
# Define a class for Pokemon so it's easier to reuse these assets to keep track of the current health and moves of a pokemon
class Pokemon:
    def __init__(self, name, hp, moves):
        """
        Initializes the POKEMON object.
        Args:
            name (str): The name of the pokemon.
            hp (int): The pokemon's hit points (HP).
            moves (list): A list of move objects that the pokemon can use.
        """
        self.name = name
        self.hp = hp
        self.moves = moves
# Define a class for Pokemon encounters so I can keep track on the enemy pokemon moves and health
class Encounter:
    def __init__(self, player_pokemon, enemy_pokemon):
        """
        Initializes the ENCOUNTER object, creating a battle between the two Pokemon (Charizard and Squirtle).
        Args:
            player_pokemon (Pokemon): The player's Pokemon.
            enemy_pokemon (Pokemon): The enemy Pokemon.
        """
        self.player_pokemon = player_pokemon
        self.enemy_pokemon = enemy_pokemon
        self.player_pokemon_hp = player_pokemon.hp
        self.enemy_pokemon_hp = enemy_pokemon.hp
    def win(self):
        """Prints a message indicating the player's pokemon won the battle."""
        print(f"Congratulations! {self.player_pokemon.name} wins!")
    def lose(self):
        """Prints a message indicating the player's pokemon lost the battle."""
        print(f"You lost! {self.player_pokemon.name} fainted.")
    #A tutorial for the player to if they need help on understanding how to fight an pokemon during the encounter phase
    def help(self):
        """Prints instructions and information about the battle system."""
        print(f"You encountered a wild {self.enemy_pokemon.name}!")
        print("You have two options during your turn:")
        print("1. Fight: Choose a move to attack.")
        print("2. Bag: Use an item to heal.")
        print("3. Run: Try to escape.")
        print("The battle continues until either Pokemon faints.")
    def fight(self):
        """Handles the player's turn in the battle, allowing them to choose a move."""
        print("")
        while True:  # This loops allows the battle to repeat until one pokemon faints 
            Moves = input(f"What move will {self.player_pokemon.name} use? \n1. {self.player_pokemon.moves[0].name}\n2. {self.player_pokemon.moves[1].name}\n3. {self.player_pokemon.moves[2].name}: ")
            try:
                Moves = int(Moves)  # Makes it easier to type a move so you can type 1 to use the first move and so on and so on
                if 1 <= Moves <= 3:
                    break
                else:
                    print("Invalid, please choose a number between 1-3")
            except ValueError:
                print("Invalid, please enter a number.")
        print("")
        #When a player chooses a move, it's finds the corresponding move associated with that number, that "move is then through a number generator specfically made for that move and will do the amount of damage that number generator gives"
        move_index = Moves - 1
        move = self.player_pokemon.moves[move_index]
        print(f"{self.player_pokemon.name} used {move.name}!")
        Damage = random.randint(move.min_damage, move.max_damage)
        if Damage == 0:
            print(f"The attack missed!")
        else:
            print(f"{self.enemy_pokemon.name} received {Damage} damage!")
            self.enemy_pokemon_hp -= Damage
            if self.enemy_pokemon_hp <= 0:
                self.win()
                return True  # if enemy pokemon variable < 0 then the battle will end
        return False  # if not then the battle continues
    def enemy_fight(self):
        """Handles the enemy pokemon's turn in the battle, choosing a move randomly."""
        print("")
        enemy_move = random.choice(self.enemy_pokemon.moves)
        print(f"{self.enemy_pokemon.name} used {enemy_move.name}!")
        Damage = random.randint(enemy_move.min_damage, enemy_move.max_damage)
        if Damage == 0:
            print(f"The attack missed!")
        else:
            print(f"{self.player_pokemon.name} received {Damage} damage!")
            self.player_pokemon_hp -= Damage
            if self.player_pokemon_hp <= 0:
                self.lose()
                return True  # same thing for the enemy pokemon, less than 0 then the battle ends
        return False  # if our pokemon is still up and running then the game continues
    def bag(self):
        """Allows the player to use items to heal their Pokemon."""
        print("")
        while True:  # If you have an item then you can use it to heal your pokemon
            Items = input(f"What item will you use for {self.player_pokemon.name}? \n1. Potion\n2. Super Potion\n3. Hyper Potion: ")
            try:
                Items = int(Items)  # 1 for the first item, 2 for the second item and so on and so on
                if 1 <= Items <= 3:
                    break
                else:
                    print("Invalid, please choose a number between 1-3")
            except ValueError:
                print("Invalid, please enter a number.")
                #Same thing for moves, an number geneator is made for each item and the number generator will heal the amount of health it gives
        if Items == 1:
            Health_restored = 20
            print(f"You used a Potion on {self.player_pokemon.name}!")
            print(f"{self.player_pokemon.name} gained {Health_restored} HP.")
            self.player_pokemon_hp += Health_restored
        elif Items == 2:
            Health_restored = 50
            print(f"You used a Super Potion on {self.player_pokemon.name}!")
            print(f"{self.player_pokemon.name} gained {Health_restored} HP.")
            self.player_pokemon_hp += Health_restored
        elif Items == 3:
            Health_restored = 100
            print(f"You used a Hyper Potion on {self.player_pokemon.name}!")
            print(f"{self.player_pokemon.name} gained {Health_restored} HP.")
            self.player_pokemon_hp += Health_restored
        if self.player_pokemon_hp > self.player_pokemon.hp:
            self.player_pokemon_hp = self.player_pokemon.hp
    def run(self):
        """Allows the player to attempt to run away from the battle."""
        while True:
            run = input(f"Are you sure you want to run? (yes/no): ")
            if run == "yes":
                #number generator 1-10 if 1 then player succesfully runs away
                run_successful = random.randint(1, 10)
                if run_successful == 1:
                    print("You successfully ran away!")
                    return True
                else:
                    print("You failed to run away!")
                    return False
            elif run == "no":
                return False
            else:
                print("Invalid, please choose a option between yes and no")
    def start(self):
        """Starts the encounter, displaying initial information and managing the battle loop."""
        self.help()
        while self.player_pokemon_hp > 0 and self.enemy_pokemon_hp > 0:
            print("")
            print(f"{self.player_pokemon.name} HP: {self.player_pokemon_hp}/{self.player_pokemon.hp}")
            print(f"{self.enemy_pokemon.name} HP: {self.enemy_pokemon_hp}/{self.enemy_pokemon.hp}")
            while True:  # Loop for valid input if user chooses anything but the items listed below then it will ask the same question again
                try:
                    choice = int(input("What would you like to do?\n1. Fight\n2. Bag\n3. Run: "))
                    if choice in [1, 2, 3]:
                        break
                    else:
                        print("Invalid. Please choose the numbers listed.")
                except ValueError:
                    print("Invalid. Please enter a number.")
            print("")
            if choice == 1:
                if self.fight():
                    break  # Battle ended We won :) 
                else:
                    if self.enemy_fight():
                        break  # Battle ended We lost :(
            elif choice == 2:
                self.bag()
                if self.enemy_fight():
                    break  # we also lose :(
            elif choice == 3:
                if self.run():
                    break  # If the correct number is assigned in the rng then you can flee and battle ends
class Shop:
    def __init__(self, name, inventory, player_gold):
        """
        Initializes the SHOP object, representing a place where the player can buy items.
        Args:
            name (str): The name of the shop.
            inventory (dict): A dictionary containing the items available for purchase and their prices.
            player_gold (int): The player's current amount of gold.
        """
        self.name = name
        self.inventory = inventory
        self.player_gold = player_gold
    def show_inventory(self):
        """Displays the items available for purchase in the shop."""
        print(f"Welcome to {self.name}!")
        print("Available items:")
        for item, price in self.inventory.items():
            print(f"- {item}: {price} gold")
    def buy_item(self):
        """Handles the purchase of an item from the shop."""
        item_to_buy = input("What would you like to buy? ").title()
        if item_to_buy in self.inventory:
            price = self.inventory[item_to_buy]
            if self.player_gold >= price:
                self.player_gold -= price
                print(f"You bought {item_to_buy} for {price} gold.")
                del self.inventory[item_to_buy]  
                print(f"You have {self.player_gold} gold left.")
            else:
                print("You don't have enough gold.")
        else:
            print(f"Sorry, we don't have {item_to_buy} in stock.")
    def interact(self):
        #Provides a loop for interacting with the shop, offering options to buy, view inventory, or leave.
        while True:
            welcome = input("Welcome traveler, how may I help you? (buy, show, leave): ").lower()
            if welcome == "buy":
                self.buy_item()
            elif welcome == "show":
                self.show_inventory()
            elif welcome == "leave":
                print("Come again soon!")
                break
            else:
                print("Invalid option. Please choose 'buy', 'show', or 'leave'.")
class Mainland:
    def __init__(self, name):
        """
        Initializes the MAINLAND object, representing the main world map.
        Args:
            name (str): The name of the mainland.
        """
        self.name = name
        self.player_gold = 20
        #Reason why squirtle HP is so low is because you have a BAG function which allows you to heal while your enemy pokemon doesn't
        self.player_pokemon = Pokemon("Squirtle", 100, [Move("Rain Splash", 10, 20), Move("Water Gun", 20, 30), Move("Hydro Pump", 30, 50)])
    def travel(self):
        """Manages the travel loop, allowing the player to choose different destinations."""
        while True:
            Area = input(f"You are on {self.name}. Where do you want to travel? (shop, grasslands, home, or quit): ").lower()
            if Area == "shop":
                shop = Shop("The Potion Shop", {"Potion": 5, "Super Potion": 10}, self.player_gold)
                shop.interact()
                print(f"You are back on {self.name}.")
            elif Area == "grasslands":
                enemy_pokemon = Pokemon("Charizard", 150, [Move("Fire Blast", 25, 45), Move("Flamethrower", 30, 60)])
                #Charizard also does more damage than squirtle so make sure you utilize all of the functions (Fight, bag and run)
                encounter = Encounter(self.player_pokemon, enemy_pokemon)
                encounter.start()
                print(f"You are back on {self.name}.")
            elif Area == "home":
                self.home()
            elif Area == "quit":
                print("Exiting the game...")
                break
            else:
                print("Invalid destination. Please choose from 'shop', 'grasslands', 'home', or 'quit'.")
    def home(self):
        """Provides a tutorial and information about the game."""
        print("\nWelcome to your cozy little home!")
        print("This is where you can learn about the world and find helpful tips.\n")
        print("Here's a quick tutorial:\n")
        print("You are a Pokemon Trainer starting your journey in a vast world.")
        print("You can explore different areas like the 'shop' to buy items")
        print("or the 'grasslands' to battle wild Pokemon.\n")
        print("You have a Squirtle as your companion.")
        print("To battle a Pokemon, use the 'Fight' option and choose a move.")
        print("You can heal your Squirtle using the 'Bag' option and using items.")
        print("If you want to try to escape, use the 'Run' option.\n")
        print("Explore, train, and become the ultimate Pokemon Master!\n")
        input("Press Enter to return to the mainland...")
        print(f"You are back on {self.name}.")
        self.travel()

""""Creates and start the game allowing some options for the player to go"""
mainland = Mainland("The Main Continent")
mainland.travel()